package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.*;


@WebServlet("/")
public class SongController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPro(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPro(request, response);
	}

	protected void doPro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String context = request.getContextPath();
		String command = request.getServletPath();
		String view = null;
		System.out.println(context + ", " + command);
		
		SongDAO song = new SongDAO();
		switch(command) {
		case "/home":
			view = "index.jsp";
			break;
		case "/search":
			view = "search.jsp";
			break;
			
		case "/searchResult":
			view = song.search(request, response);
			break;
		
		case "/list":
			view = song.showlist(request,response);
			break;
			
		case "/add":
			view = "add.jsp";
			break;
			
		case "/insert":
			int result = song.insert(request, response);
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			if (result == 1) {
				out.println("<script>");
				out.println("alert('노래 등록이 완료 되었습니다.'); location.href= '"+context+"'; ");
				out.println("</script>");
				out.flush();
			} else {
				out.println("<script>");
				out.println("alert('노래가 등록되지 못했습니다!!'); location.href= 'add';"); 
				out.println("</script>");
				out.flush();
			}
		case "/view":
			view = getView(request);
			break;
		}
		
		public int getView(HttpServletRequest request) {
			int songno = Integer.parseInt(request.getParameter("songno"));
		
		
}
		
		getServletContext().getRequestDispatcher("/"+ view).forward(request, response);
	}
	
}
