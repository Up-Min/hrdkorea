package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DTO.*;

public class SongDAO {
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	public static Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xe", "test", "test1234");
		return con;
	}
	
	public String search(HttpServletRequest request, HttpServletResponse response) {
		ArrayList<Result> searchResult = new ArrayList<Result>();	
		try {
			conn = getConnection();
			String songtitle = request.getParameter("songtitle");
			String sql = "select songno, title, singer from song where title like '%"+songtitle+"%'";
			
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Result songList = new Result();
				songList.setSongno(rs.getInt(1));
				songList.setSongtitle(rs.getString(2));
				songList.setSinger(rs.getString(3));
				
				searchResult.add(songList);
			}
			
			request.setAttribute("list", searchResult);
			
			
			conn.close();
			ps.close();
			rs.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "searchResult.jsp";
	}
	
	public String showlist(HttpServletRequest request, HttpServletResponse response) {
		ArrayList<Result> showlist = new ArrayList<Result>();	
		try {
			conn = getConnection();
			String sql = "select songno, title, singer from song order by songno";
			
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Result songList = new Result();
				songList.setSongno(rs.getInt(1));
				songList.setSongtitle(rs.getString(2));
				songList.setSinger(rs.getString(3));;
				
				showlist.add(songList);
			}
			
			request.setAttribute("showlist", showlist);
			
			
			conn.close();
			ps.close();
			rs.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "songlist.jsp";
	}
	
	public int insert(HttpServletRequest request, HttpServletResponse response) {
		int result = 0;
		try {
			conn = getConnection();
			int songno = Integer.parseInt(request.getParameter("songno"));
			String songtitle = request.getParameter("songtitle");
			String singer = request.getParameter("singer");
			String yaddress = request.getParameter("yaddress");
			
			String sql = "insert into song (songno, title, singer, yaddress) values (?,?,?,?)";
			
			ps = conn.prepareStatement(sql);
			ps.setInt(1, songno);
			ps.setString(2, songtitle);
			ps.setString(3, singer);
			ps.setString(4, yaddress);
			
			result = ps.executeUpdate();
			conn.close();
			ps.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
		
	}
	
	public String getView(int board_no) throws Exception {
		conn = getConnection();
		addSong s = new addSong();
		String sql = "select "
	}
}


